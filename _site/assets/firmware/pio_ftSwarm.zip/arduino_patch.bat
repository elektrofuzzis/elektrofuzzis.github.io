@echo off
chcp 65001 > nul
setlocal enabledelayedexpansion

set "SCRIPT_DIR=%~dp0"
set "TARGET_DIR=%LOCALAPPDATA%\Arduino15\packages\esp32\hardware\esp32\3.3.10"
set "TARGET_VARIANTS=%TARGET_DIR%\variants"

tasklist /fi "imagename eq Arduino IDE.exe" 2>nul | findstr /I /C:"Arduino IDE.exe" >nul
if "%errorlevel%"=="0" goto :IDE

tasklist /fi "imagename eq arduino.exe" 2>nul | findstr /I /C:"arduino.exe" >nul
if "%errorlevel%"=="0" goto :IDE

goto :NOIDE

:IDE
echo [ERROR] Please stop the Arduino IDE and re-run the patch script.
pause
exit /b

:NOIDE

if not exist "%TARGET_DIR%" (
    echo [ERROR] Arduino esp V3.3.10 not found.
    echo.
    pause
    exit /b
)

if exist "arduino\boards.txt" (
    echo copyiing boards.txt...
    copy /Y "%SCRIPT_DIR%arduino\boards.txt" "%TARGET_DIR%\" > nul
) else (
    echo [ERROR] Keine boards.txt im Unterverzeichnis 'arduino' gefunden.
)

if exist "variants" (
    echo copying variants...
    xcopy "%SCRIPT_DIR%variants" "%TARGET_VARIANTS%" /E /I /Y > nul
) else (
    echo [HINWEIS] Kein lokales 'variants'-Verzeichnis im Skriptordner gefunden.
)

echo.
echo =====================================================
echo V3.3.10 successfully patched. 
echo Restart arduino-ide and use ftSwarm board defintions.
echo =====================================================
echo.
pause
exit /b
