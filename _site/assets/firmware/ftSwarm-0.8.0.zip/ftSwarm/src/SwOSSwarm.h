/*
 * SwOSSwarm.h
 *
 * internal represenation of my swarm. Use FtSwarm-Classes in FtSwarm.h to access your swarm!
 * 
 * (C) 2021/22 Christian Bergschneider & Stefan Fuss
 * 
 */
 
#pragma once

#include "SwOS.h"

#include <stdint.h>
#include <esp_now.h>

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>

#include "serialize.h"
#include "SwOSCom.h"
#include "SwOSHW.h"
#include "SwOSNVS.h"

class SwOSSwarm {
protected:
  struct PendingIOConfigPacket {
    SwOSCom *com;
    PendingIOConfigPacket *next;
  };

  struct PendingIOConfig {
    bool valid = false;
    SwOSCtrlConfig_t ctrlConfig;
    PendingIOConfigPacket *first = NULL;
    PendingIOConfigPacket *last = NULL;
  };

  PendingIOConfig pendingIOConfig[MAXCTRL];

  uint16_t readDelay = 25;
  bool     verbose = false;
  bool     initialized = false;

	bool     splitID( char *id, uint8_t *index, char *io, size_t sizeIO);  // split identifier
  SwOSIO  *waitFor( char *alias );
  void     startWifi( void );

  // replace controller in swarm list
  void replaceCtrl( SwOSCom *com, uint8_t source, uint8_t affected, const SwOSCtrlConfig_t *ctrlConfig = NULL );
  void clearPendingIOConfig( uint8_t index );
  bool queuePendingIOConfig( uint8_t index, SwOSCom *com );
  void replayPendingIOConfig( uint8_t index );

  // process CMD_JOINMYSWARM
  void cmdJoinMySwarm( SwOSCom *com, uint8_t source, uint8_t affected );

  // Member to Kelda: I don't want to join your Swarm
  void cmdJoinNAck( SwOSCom *com, uint8_t source, uint8_t affected );
  
  // Member to Kelda: I want to join your Swarm
  void cmdJoinAck( SwOSCom *com, uint8_t source, uint8_t affected );

  // Kelda to Member: get out of my Swarm
  void cmdRevokeFromSwarm( SwOSCom *com, uint8_t source, uint8_t affected );

public:
  uint8_t  sync = 0;
  int8_t   maxCtrl = -1;
  SwOSCtrl *Kelda = NULL;
	SwOSCtrl *Ctrl[MAXCTRL];
  bool     wifiConnected = false;

  // constructor
  SwOSSwarm( ) { for ( uint8_t i=0; i<MAXCTRL; i++ ) { Ctrl[i] = NULL; } }; 

  // Start the swarm. If verbose is set, do some inormational console output
  FtSwarmSerialNumber_t begin( bool verbose );

  // test on factoryReset
  void testFactoryReset( void );

  // factoryReset & reboot
  void factoryReset( void );

  // Stop all motors within the swarm
  void halt( void );

  // unsibscribe all subscribed IO's  
  void unsubscribe( void ); 

  // Get a controller in the swarm using his name/alias. Returns the controller's pointer or NULL if it doesn't exist.
	SwOSCtrl* getController(char *name);

  // Get a controller in the swarm using his serial number. Returns the controller's pointer or NULL if it doesn't exist.
  SwOSCtrl* getController( FtSwarmSerialNumber_t SN );

  // return index of controller with this s/n or are free slot if not found
  uint8_t  getIndex( FtSwarmSerialNumber_t serialNumber );

  // Get an IO in the swarm using controllers serial number, port and ioType. Returns the IO's pointer or NULL if it doesn't exist.
  virtual SwOSIO* getIO( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, SwOSIOType_t ioType );

  // Get an IO in the swarm using io's uid. Returns the IO's pointer or NULL if it doesn't exist.
  virtual SwOSIO* getIO( SwOSIOUID uio ) { return getIO( uio.serialNumber, uio.port, uio.ioType ); };

  // Get an IO in the swarm using controllers serial number, port and ioType. Returns the IO's alias name
  virtual void getAlias( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, SwOSIOType_t ioType, char *alias );
 
  // Get an IO in the swarm using controllers serial number, port and ioType. Returns the IO's alias name
  virtual void getAliasOrName( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, SwOSIOType_t ioType, char *alias );

  // Get an IO in the swarm using io's uid. Returns the IO's alias name
  virtual void getAlias( SwOSIOUID uio, char *alias ) { getAlias( uio.serialNumber, uio.port, uio.ioType, alias ); };

  // Get an IO in the swarm using io's uid. Returns the IO's alias name
  virtual void getAliasOrName( SwOSIOUID uio, char *alias ) { getAliasOrName( uio.serialNumber, uio.port, uio.ioType, alias ); };

  // Get an IO in the swarm using his name/alias and ioType. Returns the IO#s pointer or NULL if it doesn't exist.
  virtual SwOSIO* getIO( const char *name, SwOSIOType_t ioType = SWOSIO_UNDEF );

  // search for offline or unconnected controllers and try to get them
  virtual void connect( void );

  // get swarm's read delay
  uint16_t getReadDelay( void ) { return readDelay; };

  // test, if an IO is available in the swarm. Returns true if available, false if not. 
  bool IOAvaliable( const char *name );

  // **** API ****
  size_t approxSerialize( SerialFormat_t format );
	void serialize( Serialize *serialize );                                                        // transfer my swarm to a JSON structure
  void serializeEvents( Serialize *serialize );

  void setState( SwOSState_t state, const char *errorText = nullptr ); 

  // receiving data from other controllers
  void OnDataRecv( SwOSCom *buffer );

  // As a Kelda send CMD_JOINMYSWARM to a potential member
  void joinMySwarm( MacAddr destinationMac, FtSwarmSerialNumber_t destinationSN ); 
  
  // **** some useful stuff ****

  // # of members in swarm
  uint8_t members( void ); 
  
  // create a new swam based on nvs settings
  void newSwarm( void );  
  
  // Test, if SN is part my my Swarm 
  bool isMember( FtSwarmSerialNumber_t serialNumber );  
  
  // Test, if SN is online
  bool isOnline( FtSwarmSerialNumber_t serialNumber );  
  
  // Test, if complete swarm is online
  bool isOnline( void );  

  // add Controller SN to the swarm
  bool addController( FtSwarmSerialNumber_t serialNumber );    

  // delete Controller SN
  bool deleteController( FtSwarmSerialNumber_t serialNumber ); 

  // delete an event
  bool deleteEvent( SwOSNVSEvent *event );

  // add an event
  bool addEvent( SwOSNVSEvent *event );

  // add all events
  void addEvents( uint8_t config, FtSwarmSerialNumber_t sn = 0 );

  // delete all events
  void deleteEvents( void );

  void save( FtSwarmNVSScope_t scope );

};

extern SwOSSwarm myOSSwarm;
