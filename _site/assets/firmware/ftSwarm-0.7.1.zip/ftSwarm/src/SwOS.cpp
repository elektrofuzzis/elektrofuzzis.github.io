/*
 * ftSwarm.cpp
 *
 * framework to build a ftSwarm application
 * 
 * (C) 2021/22 Christian Bergschneider & Stefan Fuss
 * 
 */
 
#include "SwOS.h" 
#include "SwOSSwarm.h"
#include "easyKey.h"
#include "SwOSLog.h"
#include <FastLed.h>

#include <MPU6050_6Axis_MotionApps20.h>

CRGB castUI32ToColor(uint32_t color) {
    uint8_t r = (uint8_t)((color >> 16) & 0xFF);
    uint8_t g = (uint8_t)((color >> 8) & 0xFF);
    uint8_t b = (uint8_t)(color & 0xFF);
    return CRGB(r, g, b);
}

uint32_t castColorToUI32(CRGB color) {
    return ((uint32_t)color.r << 16) | ((uint32_t)color.g << 8) | (uint32_t)color.b;
}

void FtSwarmTriggerParameter::setValue( int32_t value ) {

  // don't set values, if effect is set, because effect has no value, only parameters
  if ( (FtSwarmEffect_t) base.effectType != FTSWARM_EFFECT_NONE ) return;

  base.value = abs(value);
  base.sign  = ( value < 0 );

}

int32_t FtSwarmTriggerParameter::getValue( void ) {

  // don't set values, if effect is set, because effect has no value, only parameters
  if ( (FtSwarmEffect_t) base.effectType != FTSWARM_EFFECT_NONE ) return 0;

  if ( base.sign ) return - base.value;
  else             return   base.value;

}

void FtSwarmTriggerParameter::print( void ) {

  printf("raw: %08X\n", raw );

  switch ( getEffectType() ) {

    case FTSWARM_EFFECT_BLINK:  printf( "FTSWARM_EFFECT_BLINK period %d, signal beats: %d, duty: %d, pause beats: %d, p3: %d, P2: %d, P1: %d\n", 
                                        blink.period, blink.signal, blink.duty, blink.pause, blink.p3, blink.p2, blink.p1 );
                                break;
    case FTSWARM_EFFECT_NONE:   printf( "FTSWARM_EFFECT_NONE sign: %d, value: %06X, getValue %06X\n",
                                        base.sign, base.value, getValue() );
                                break;

    default:                    printf( "unkown effect type %d\n", base.effectType ) ;
                                break;

    }
  
}

uint32_t FtSwarmTriggerParameter::getPeriod( void ) {

  return ( blink.period + 1 ) * 250;

}

void FtSwarmTriggerParameter::setPeriod( uint32_t period ) {

  if      ( period <  500 ) blink.period = 0;
  else if ( period > 7000 ) blink.period = 31;
  else                      blink.period = period / 250 - 1;

}

void FtSwarmTriggerParameter::setBlink( uint32_t periodMS, uint8_t signal, uint8_t duty, uint8_t pause, uint8_t p1, uint8_t p2, uint8_t p3 ) {

  blink.effectType = FTSWARM_EFFECT_BLINK;
  
  setPeriod( periodMS);

  blink.signal     = signal;
  blink.duty       = duty;
  blink.pause      = pause;
  blink.p1         = p1;
  blink.p2         = p2;
  blink.p3         = p3;

}

bool FtSwarmTriggerParameter::getBlink( uint32_t *periodMS, uint8_t *signal, uint8_t *duty, uint8_t *pause, uint8_t *p1, uint8_t *p2, uint8_t *p3 ) {

  if ( getEffectType() != FTSWARM_EFFECT_BLINK ) return false;

  *periodMS = getPeriod();
  *signal   = blink.signal;
  *duty     = blink.duty;
  *pause    = blink.pause;
  *p1       = blink.p1;
  *p2       = blink.p2;
  *p3       = blink.p3;
  
  return true;
  
}


SwOSPID::SwOSPID( float kp, float ki, float kd, float min_integral, float max_integral, float min_output, float max_output ) {
  this->kp = kp;
  this->ki = ki;
  this->kd = kd;
  this->min_integral = min_integral;
  this->max_integral = max_integral;
  this->min_output   = min_output;
  this->max_output   = max_output;
}

float SwOSPID::solve( float target, float sensor ) {

  float error = target - sensor;
  integral += error;
  integral = max( integral, max_integral );
  integral = min( integral, min_integral );
  float derivative = ( error - last_error);
  float output = kp * error + ki * integral + kd * derivative;
  output = min( output, max_output );
  output = max( output, min_output );
  last_error = error;
  return output;

}

FtSwarm ftSwarm;

// **** FtSwarmIO ****

FtSwarmIO::FtSwarmIO( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, SwOSIOType_t ioType ) {
  // constructor: register at myOSSwarm and get a pointer to myself
  bool firstTry = true;

  while (!me) {

    // check, if IO is online
    me = (SwOSIOHandle_t) myOSSwarm.getIO( serialNumber, port, ioType);
    
    // no success, wait 25 ms
    if ( (!me) && ( firstTry ) ) {
      SWARM_LOG_WAIT( TRANSLATE( "Waiting for device - SN controller: %d port: %d ioType: %d\n", "Warte auf Gerät - SN Controller: %d Port: %d ioType: %d\n" ), serialNumber, port, ioType );
      firstTry = false;
    }
    
    if (!me) vTaskDelay( 25 / portTICK_PERIOD_MS );
  }

  // block, if port is not available
  if ( static_cast<SwOSIO *>(me)->testFlag( FTSWARM_HAL_FLAG_HIDDEN ) ) SWARM_LOG_FATAL( TRANSLATE( "ftSwarm%d ioType %d port %d is blocked by another IO\n", "ftSwarm%d ioType %d port %d ist von einem anderen IO blockiert\n" ), serialNumber, ioType, port );

  // register myself
  static_cast<SwOSIO *>(me)->lock();
  static_cast<SwOSIO *>(me)->take();
  static_cast<SwOSIO *>(me)->unlock(); 
  
};

FtSwarmIO::FtSwarmIO( FtSwarmSerialNumber_t serialNumber, SwOSIOType_t ioType ):FtSwarmIO(serialNumber, SWOS_NOPORT, ioType ) {
  // helper for all devices, which don't have a port like CAM, OLED, ...
};

FtSwarmIO::FtSwarmIO( const char *name, SwOSIOType_t ioType ) {
  // constructor: register at myOSSwarm using a name/alias

  bool firstTry = true;

  while (!me) {

    me = myOSSwarm.getIO( name, ioType );

    // no success, wait 25 ms
    if ( (!me) && ( firstTry ) ) {
      SWARM_LOG_WAIT( TRANSLATE( "Waiting for device %s ioType: %d\n", "Warte auf Gerät %s ioType: %d\n" ), name, ioType );
      firstTry = false;
    }
    
    if (!me) vTaskDelay( 25 / portTICK_PERIOD_MS );
 
  }

  // block, if port is not available
  if ( static_cast<SwOSIO *>(me)->testFlag( FTSWARM_HAL_FLAG_HIDDEN ) ) SWARM_LOG_FATAL( TRANSLATE( "IO %s ioType %s is blocked by another IO\n", "IO %s ioType %s ist von einem anderen IO blockiert\n" ), name, ioType );
  // register myself
  static_cast<SwOSIO *>(me)->lock(); 
  static_cast<SwOSIO *>(me)->take();
  static_cast<SwOSIO *>(me)->unlock(); 
  
}

FtSwarmIO::~FtSwarmIO() {

  // unregister myself
  if (me) {
    static_cast<SwOSIO *>(me)->lock(); 
    static_cast<SwOSIO *>(me)->give();
    static_cast<SwOSIO *>(me)->unlock(); 
  }
}

bool FtSwarmIO::isOnline() { 
  // check if I'm online
  return (me)?static_cast<SwOSIO *>(me)->isOnline():false;
};

// **** FtSwarmSensor

FtSwarmSensor::FtSwarmSensor( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, SwOSIOType_t ioType):FtSwarmIO( serialNumber, port, ioType ) {
  // constructor: register at myOSSwarm and get a pointer to myself 

};

FtSwarmSensor::FtSwarmSensor( const char *name, SwOSIOType_t ioType ):FtSwarmIO( name, ioType ) {

};

void FtSwarmSensor::onTrigger( FtSwarmTrigger_t triggerEvent, FtSwarmOperator_t op, FtSwarmOperand_t v1, FtSwarmOperand_t v2, FtSwarmIO *actor, FtSwarmTriggerParameter p1 ) {

  // set trigger using static values
  if ( (me) && (actor) ) {
    static_cast<SwOSInput *>(me)->lock();
    static_cast<SwOSInput *>(me)->addEvent( triggerEvent, op, v1, v2, static_cast<SwOSIO*>(actor->me), p1 );
    static_cast<SwOSInput *>(me)->unlock();
  }

};

// **** FtSwarmDigitalInput ****

FtSwarmDigitalInput::FtSwarmDigitalInput( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, SwOSIOType_t ioType, bool normallyOpen):FtSwarmSensor( serialNumber, port, SWOSIO_DIGITAL ) {
  
  if (me) static_cast<SwOSInput *>(me)->setParameter( normallyOpen );

}

FtSwarmDigitalInput::FtSwarmDigitalInput( const char *name, SwOSIOType_t ioType, bool normallyOpen ):FtSwarmSensor( name, ioType) {

  if (me) static_cast<SwOSInput *>(me)->setParameter( normallyOpen );

}

FtSwarmDigitalInput::FtSwarmDigitalInput( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, bool normallyOpen ) :FtSwarmSensor( serialNumber, port, SWOSIO_DIGITAL ) {

  if (me) static_cast<SwOSInput *>(me)->setParameter( normallyOpen );

}

FtSwarmDigitalInput::FtSwarmDigitalInput( const char *name, bool normallyOpen ):FtSwarmSensor( name, SWOSIO_DIGITAL) {

  if (me) static_cast<SwOSInput *>(me)->setParameter( normallyOpen );

}


// some facades
bool FtSwarmDigitalInput::isPressed()            { return getState(); };
bool FtSwarmDigitalInput::isReleased()           { return !getState(); };
bool FtSwarmDigitalInput::hasToggledUp()         { return ( getToggle() == FTSWARM_TOGGLEUP ); };
bool FtSwarmDigitalInput::hasToggledDown()       { return ( getToggle() == FTSWARM_TOGGLEDOWN ); };

// real stuff
FtSwarmToggle_t FtSwarmDigitalInput::getToggle() { 

  if (!me) return FTSWARM_NOTOGGLE;

  static_cast<SwOSDigitalInput *>(me)->lock();
  FtSwarmToggle_t xReturn = static_cast<SwOSDigitalInput *>(me)->getToggle();
  static_cast<SwOSDigitalInput *>(me)->unlock();

  return xReturn;
};

bool FtSwarmDigitalInput::getState() { 

  if (!me) return false;

  static_cast<SwOSDigitalInput *>(me)->lock();
  bool xReturn = (static_cast<SwOSDigitalInput *>(me)->getValueI32()>0);
  static_cast<SwOSDigitalInput *>(me)->unlock();

  return xReturn;
};

// **** FtSwarmSwitch ****

FtSwarmSwitch::FtSwarmSwitch( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, bool normallyOpen):FtSwarmDigitalInput( serialNumber, port, SWOSIO_SWITCH, normallyOpen ) {};
FtSwarmSwitch::FtSwarmSwitch( const char * name, bool normallyOpen):FtSwarmDigitalInput( name, SWOSIO_SWITCH, normallyOpen ) {};

// **** FtSwarmLightBarrier ****

FtSwarmLightBarrier::FtSwarmLightBarrier( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, bool normallyOpen):FtSwarmDigitalInput( serialNumber, port, SWOSIO_LIGHTBARRIER, normallyOpen ) {};
FtSwarmLightBarrier::FtSwarmLightBarrier( const char * name, bool normallyOpen):FtSwarmDigitalInput( name, SWOSIO_LIGHTBARRIER, normallyOpen ) {};

// **** FtSwarmReedSwitch ****

FtSwarmReedSwitch::FtSwarmReedSwitch( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, bool normallyOpen):FtSwarmDigitalInput( serialNumber, port, SWOSIO_REEDSWITCH, normallyOpen ) {};
FtSwarmReedSwitch::FtSwarmReedSwitch( const char * name, bool normallyOpen):FtSwarmDigitalInput( name, SWOSIO_REEDSWITCH, normallyOpen ) {};

// **** FtSwarmButton ****

FtSwarmButton::FtSwarmButton( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmDigitalInput( serialNumber, port, SWOSIO_BUTTON ) {};
FtSwarmButton::FtSwarmButton( const char *name):FtSwarmDigitalInput( name, SWOSIO_BUTTON, true ) {};

// **** FtSwarmCounter

FtSwarmCounter::FtSwarmCounter( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, SwOSIOType_t ioType ):FtSwarmSensor( serialNumber, port, SWOSIO_COUNTER ) {

};

FtSwarmCounter::FtSwarmCounter( const char *name, SwOSIOType_t ioType ):FtSwarmSensor( name, SWOSIO_COUNTER ) {
  
};

FtSwarmCounter::FtSwarmCounter( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmCounter( serialNumber, port, SWOSIO_COUNTER ) {

};

FtSwarmCounter::FtSwarmCounter( const char *name):FtSwarmCounter( name, SWOSIO_COUNTER ) {

};

int16_t FtSwarmCounter::getCounter() {

  if (!me) return 0;

  static_cast<SwOSCounter *>(me)->lock();
  uint16_t xReturn = (static_cast<SwOSCounter *>(me)->getValueI32());
  static_cast<SwOSCounter *>(me)->unlock();

  return xReturn;
};

void FtSwarmCounter::resetCounter( void ) {

  static_cast<SwOSCounter *>(me)->lock();
  static_cast<SwOSCounter *>(me)->resetCounter();
  static_cast<SwOSCounter *>(me)->unlock();

};

// **** FtSwarmRotaryEncoder

FtSwarmRotaryEncoder::FtSwarmRotaryEncoder( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, SwOSIOType_t ioType ):FtSwarmSensor( serialNumber, port, SWOSIO_ROTARYENCODER ) {

};

FtSwarmRotaryEncoder::FtSwarmRotaryEncoder( const char *name, SwOSIOType_t ioType ):FtSwarmSensor( name, SWOSIO_ROTARYENCODER ) {
  
};

FtSwarmRotaryEncoder::FtSwarmRotaryEncoder( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmRotaryEncoder( serialNumber, port, SWOSIO_ROTARYENCODER ) {

};

FtSwarmRotaryEncoder::FtSwarmRotaryEncoder( const char *name):FtSwarmRotaryEncoder( name, SWOSIO_ROTARYENCODER ) {

};

int16_t FtSwarmRotaryEncoder::getCounter() {

  if (!me) return 0;

  static_cast<SwOSCounter *>(me)->lock();
  uint16_t xReturn = (static_cast<SwOSCounter *>(me)->getValueI32());
  static_cast<SwOSCounter *>(me)->unlock();

  return xReturn;
};

void FtSwarmRotaryEncoder::resetCounter( void ) {

  static_cast<SwOSCounter *>(me)->lock();
  static_cast<SwOSCounter *>(me)->resetCounter();
  static_cast<SwOSCounter *>(me)->unlock();

};

// **** FtSwarmFrequencymeter

FtSwarmFrequencymeter::FtSwarmFrequencymeter( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmSensor( serialNumber, port, SWOSIO_FREQUENCYMETER ) {

};

FtSwarmFrequencymeter::FtSwarmFrequencymeter( const char *name ):FtSwarmSensor( name, SWOSIO_FREQUENCYMETER ) {

};

int16_t FtSwarmFrequencymeter::getFrequency() {

  if (!me) return 0;

  static_cast<SwOSFrequencymeter *>(me)->lock();
  uint16_t xReturn = (static_cast<SwOSFrequencymeter *>(me)->getValueI32());
  static_cast<SwOSFrequencymeter *>(me)->unlock();

  return xReturn;
};

// **** FtSwarmAnalogInput ****

FtSwarmAnalogInput::FtSwarmAnalogInput( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, SwOSIOType_t ioType):FtSwarmSensor( serialNumber, port, SWOSIO_ANALOG ) {

};

FtSwarmAnalogInput::FtSwarmAnalogInput( const char *name, SwOSIOType_t ioType ):FtSwarmSensor( name, SWOSIO_ANALOG ) {

};

FtSwarmAnalogInput::FtSwarmAnalogInput( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port ):FtSwarmSensor( serialNumber, port, SWOSIO_ANALOG ) {

}
    
FtSwarmAnalogInput::FtSwarmAnalogInput( const char *name ):FtSwarmSensor( name, SWOSIO_ANALOG ) {

}


int32_t FtSwarmAnalogInput::getValue() {

  if (!me) return 0;

  static_cast<SwOSInput *>(me)->lock();
  uint16_t xReturn = (static_cast<SwOSInput *>(me)->getValueI32());
  static_cast<SwOSInput *>(me)->unlock();

  return xReturn;
};

// **** FtSwarmVoltmeter ****

FtSwarmVoltmeter::FtSwarmVoltmeter( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmAnalogInput( serialNumber, port, SWOSIO_VOLTMETER ) {};
FtSwarmVoltmeter::FtSwarmVoltmeter( const char *name ):FtSwarmAnalogInput( name, SWOSIO_VOLTMETER ) {};

float FtSwarmVoltmeter::getVoltage() {

  if (!me) return 0;

  static_cast<SwOSAnalogInput *>(me)->lock();
  float xReturn = (static_cast<SwOSAnalogInput *>(me)->getVoltage());
  static_cast<SwOSAnalogInput *>(me)->unlock();

  return xReturn;
};

// **** FtSwarmOhmmeter ****

FtSwarmOhmmeter::FtSwarmOhmmeter( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmAnalogInput( serialNumber, port, SWOSIO_OHMMETER ) {};
FtSwarmOhmmeter::FtSwarmOhmmeter( const char *name ):FtSwarmAnalogInput( name, SWOSIO_OHMMETER ) {};

float FtSwarmOhmmeter::getResistance() {

  if (!me) return 0;

  static_cast<SwOSAnalogInput *>(me)->lock();
  float xReturn = (static_cast<SwOSAnalogInput *>(me)->getResistance());
  static_cast<SwOSAnalogInput *>(me)->unlock();

  return xReturn;
};

// **** FtSwarmThermometer ****

FtSwarmThermometer::FtSwarmThermometer( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmAnalogInput( serialNumber, port, SWOSIO_THERMOMETER ) {};
FtSwarmThermometer::FtSwarmThermometer( const char *name ):FtSwarmAnalogInput( name, SWOSIO_THERMOMETER ) {};

float FtSwarmThermometer::getCelcius() {

  if (!me) return 0;

  static_cast<SwOSAnalogInput *>(me)->lock();
  float xReturn = (static_cast<SwOSAnalogInput *>(me)->getCelcius());
  static_cast<SwOSAnalogInput *>(me)->unlock();

  return xReturn;
};

float FtSwarmThermometer::getKelvin() {
  if (!me) return 0;

  static_cast<SwOSAnalogInput *>(me)->lock();
  float xReturn = (static_cast<SwOSAnalogInput *>(me)->getKelvin());
  static_cast<SwOSAnalogInput *>(me)->unlock();

  return xReturn;
}

float FtSwarmThermometer::getFahrenheit() {
  if (!me) return 0;

  static_cast<SwOSAnalogInput *>(me)->lock();
  float xReturn = (static_cast<SwOSAnalogInput *>(me)->getFahrenheit());
  static_cast<SwOSAnalogInput *>(me)->unlock();

  return xReturn;
}


// **** FtSwarmLDR ****

FtSwarmLDR::FtSwarmLDR( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmAnalogInput( serialNumber, port, SWOSIO_LDR ) {};
FtSwarmLDR::FtSwarmLDR( const char *name ):FtSwarmAnalogInput( name, SWOSIO_LDR ) {};

// **** FtSwarmMotor ****

FtSwarmMotor::FtSwarmMotor( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, SwOSIOType_t ioType):FtSwarmIO( serialNumber, port, ioType) {

};

FtSwarmMotor::FtSwarmMotor( const char *name, SwOSIOType_t ioType):FtSwarmIO( name, ioType ) {
  
};
    
void FtSwarmMotor::setSpeed( int16_t speed ) {
  if (me) {
    static_cast<SwOSMotor *>(me)->lock();
    static_cast<SwOSMotor *>(me)->setSpeed( speed );
    static_cast<SwOSMotor *>(me)->apply();
    static_cast<SwOSMotor *>(me)->unlock();
  }
}

uint16_t FtSwarmMotor::getSpeed() {

  if (!me) return 0;

  static_cast<SwOSMotor *>(me)->lock();
  uint16_t xReturn = (static_cast<SwOSMotor *>(me)->getSpeed());
  static_cast<SwOSMotor *>(me)->unlock();

  return xReturn;
};

void FtSwarmMotor::setAcceleration( uint32_t rampUpT, uint32_t rampUpY ) {
  if (me) {
    static_cast<SwOSMotor *>(me)->lock();
    static_cast<SwOSMotor *>(me)->setAcceleration( rampUpT, rampUpY );
    static_cast<SwOSMotor *>(me)->unlock();
  }
}

void FtSwarmMotor::getAcceleration( uint32_t *rampUpT, uint32_t *rampUpY ) {

  if (!me) return;

  static_cast<SwOSMotor *>(me)->lock();
  static_cast<SwOSMotor *>(me)->getAcceleration( rampUpT, rampUpY );
  static_cast<SwOSMotor *>(me)->unlock();

};

// **** FtSwarmTractorMotor

FtSwarmTractorMotor::FtSwarmTractorMotor( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, SwOSIOType_t ioType):FtSwarmMotor( serialNumber, port, ioType) {};
FtSwarmTractorMotor::FtSwarmTractorMotor( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmMotor( serialNumber, port, SWOSIO_TRACTOR) {};
FtSwarmTractorMotor::FtSwarmTractorMotor( const char *name, SwOSIOType_t ioType ):FtSwarmMotor( name, ioType ) {};
FtSwarmTractorMotor::FtSwarmTractorMotor( const char *name ):FtSwarmMotor( name, SWOSIO_TRACTOR ) {};

void FtSwarmTractorMotor::setMotionType( FtSwarmMotion_t motionType ) {
  if (me) {
    static_cast<SwOSMotor *>(me)->lock();
    static_cast<SwOSMotor *>(me)->setMotionType( motionType );
    static_cast<SwOSMotor *>(me)->unlock();
  }
}

FtSwarmMotion_t FtSwarmTractorMotor::getMotionType( void ) {
  
  FtSwarmMotion_t motionType = FTSWARM_COAST;
  
  if (me) {
    static_cast<SwOSMotor *>(me)->lock();
    motionType = static_cast<SwOSMotor *>(me)->getMotionType( );
    static_cast<SwOSMotor *>(me)->unlock();
  }

  return motionType;
  
}

// **** FtSwarmStepperMotor

FtSwarmStepperMotor::FtSwarmStepperMotor( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmTractorMotor( serialNumber, port, SWOSIO_STEPPER ) {};
FtSwarmStepperMotor::FtSwarmStepperMotor( const char * name ):FtSwarmTractorMotor( name, SWOSIO_STEPPER ) {};

void FtSwarmStepperMotor::setDistance( int32_t distance, bool relative ) {

  if (me) {
    static_cast<SwOSStepper *>(me)->lock();
    static_cast<SwOSStepper *>(me)->setDistance( distance, relative );
    static_cast<SwOSStepper *>(me)->unlock();
  }

}

int32_t FtSwarmStepperMotor::getDistance( void ) {

  int32_t distance = 0;

  if (me) {
    static_cast<SwOSStepper *>(me)->lock();
    distance = static_cast<SwOSStepper *>(me)->getDistance( );
    static_cast<SwOSStepper *>(me)->unlock();
  }

  return distance;

}

bool FtSwarmStepperMotor::isRunning( void ) {

  bool result = false;

  if (me) {
    static_cast<SwOSStepper *>(me)->lock();
    result = static_cast<SwOSStepper *>(me)->isRunning( );
    static_cast<SwOSStepper *>(me)->unlock();
  }

  return result;

}

void FtSwarmStepperMotor::run( void ) {

  if (me) {
    static_cast<SwOSStepper *>(me)->lock();
    static_cast<SwOSStepper *>(me)->startStop( true );
    static_cast<SwOSStepper *>(me)->unlock();
  }

}

void FtSwarmStepperMotor::stop( void ) {

  if (me) {
    static_cast<SwOSStepper *>(me)->lock();
    static_cast<SwOSStepper *>(me)->startStop( false );
    static_cast<SwOSStepper *>(me)->unlock();
  }

}

void FtSwarmStepperMotor::setPosition( int32_t position ) {

  if (me) {
    static_cast<SwOSStepper *>(me)->lock();
    static_cast<SwOSStepper *>(me)->setPosition( position );
    static_cast<SwOSStepper *>(me)->unlock();
  }

}

int32_t FtSwarmStepperMotor::getPosition( void ) {

  int32_t position = 0;

  if (me) {
    static_cast<SwOSStepper *>(me)->lock();
    position = static_cast<SwOSStepper *>(me)->getPosition( );
    static_cast<SwOSStepper *>(me)->unlock();
  }

  return position;

}

bool FtSwarmStepperMotor::isHoming( void ) {

  bool result = false;

  if (me) {
    static_cast<SwOSStepper *>(me)->lock();
    result = static_cast<SwOSStepper *>(me)->isHoming( );
    static_cast<SwOSStepper *>(me)->unlock();
  }

  return result;

}

void FtSwarmStepperMotor::homing( int32_t maxDistance ) {

  if (me) {
    static_cast<SwOSStepper *>(me)->lock();
    static_cast<SwOSStepper *>(me)->homing( maxDistance );
    static_cast<SwOSStepper *>(me)->unlock();
  }

}

void FtSwarmStepperMotor::setHomingOffset( int32_t offset ) {

  if (me) {
    static_cast<SwOSStepper *>(me)->lock();
    static_cast<SwOSStepper *>(me)->setHomingOffset( offset );
    static_cast<SwOSStepper *>(me)->unlock();
  }

}

// **** FtSwarmOnOffActor ****

FtSwarmOnOffActor::FtSwarmOnOffActor( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, SwOSIOType_t ioType):FtSwarmMotor( serialNumber, port, ioType ) {};
FtSwarmOnOffActor::FtSwarmOnOffActor( const char *name, SwOSIOType_t ioType ):FtSwarmMotor( name, ioType ) {};

void FtSwarmOnOffActor::on( int16_t speed ) {
  if (me) {
    static_cast<SwOSMotor *>(me)->lock();
    static_cast<SwOSMotor *>(me)->setSpeed(speed);
    static_cast<SwOSMotor *>(me)->apply();
    static_cast<SwOSMotor *>(me)->unlock();
  }
}

void FtSwarmOnOffActor::off( void ) {
  on(0);
}

// **** FtSwarmLamp ****

FtSwarmLamp::FtSwarmLamp( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmOnOffActor( serialNumber, port, SWOSIO_LAMP ) {};
FtSwarmLamp::FtSwarmLamp( const char *name ):FtSwarmOnOffActor( name, SWOSIO_LAMP ) {};

void FtSwarmLamp::setBlink( uint32_t periodMS, uint8_t signal, uint8_t duty, uint8_t pause, uint8_t b1, uint8_t b2, uint8_t b3 ) {

  if (!me) return;

  SwOSLamp *lamp = static_cast<SwOSLamp*>(me);
  
  FtSwarmTriggerParameter p;
  p.setBlink( periodMS, signal, duty, pause, b1, b2, b3 );

  lamp->lock();
  lamp->setEffect( p );
  lamp->unlock();

}

void FtSwarmLamp::revokeEffect( uint8_t brightness ) {

  if (!me) return;

  SwOSLamp *lamp = static_cast<SwOSLamp*>(me);
  
  FtSwarmTriggerParameter p;
  p.setNone( brightness );

  lamp->lock();
  lamp->setEffect( p );
  lamp->unlock();

}

// **** FtSwarmValve ****

FtSwarmValve::FtSwarmValve( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmOnOffActor( serialNumber, port, SWOSIO_VALVE ) {};
FtSwarmValve::FtSwarmValve( const char *name ):FtSwarmOnOffActor( name, SWOSIO_LAMP ) {};


// **** FtSwarmCompressor ****

FtSwarmCompressor::FtSwarmCompressor( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmOnOffActor( serialNumber, port, SWOSIO_VALVE ) {};
FtSwarmCompressor::FtSwarmCompressor( const char *name ):FtSwarmOnOffActor( name, SWOSIO_COMPRESSOR ) {};

// **** FtSwarmBuzzer ****

FtSwarmBuzzer::FtSwarmBuzzer( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmOnOffActor( serialNumber, port, SWOSIO_VALVE ) {};
FtSwarmBuzzer::FtSwarmBuzzer( const char *name ):FtSwarmOnOffActor( name, SWOSIO_BUZZER ) {};


// **** FtSwarmJoystick ****

FtSwarmJoystick::FtSwarmJoystick( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmIO(serialNumber, port, SWOSIO_JOYSTICK) {

  // add joystick button
  switch (port) {
    case FTSWARM_JOY1: button = myOSSwarm.getIO( serialNumber, FTSWARM_J1, SWOSIO_BUTTON); break;
    case FTSWARM_JOY2: button = myOSSwarm.getIO( serialNumber, FTSWARM_J2, SWOSIO_BUTTON); break;
    default:           button = NULL;
  }

};

FtSwarmJoystick::FtSwarmJoystick( const char *name ):FtSwarmIO( name, SWOSIO_JOYSTICK ) {

  // add joystick button
  SwOSJoystick *joystick = static_cast<SwOSJoystick *>(me);
  switch (joystick->getPort()) {
    case FTSWARM_JOY1: button = myOSSwarm.getIO( joystick->getCtrl()->serialNumber, FTSWARM_J1, SWOSIO_BUTTON); break;
    case FTSWARM_JOY2: button = myOSSwarm.getIO( joystick->getCtrl()->serialNumber, FTSWARM_J2, SWOSIO_BUTTON); break;
    default:           button = NULL;
  }

};

int16_t FtSwarmJoystick::getFB() {
  int16_t FB, LR;
  boolean b;
  getValue( &FB, &LR, &b );
  return FB;
}

int16_t FtSwarmJoystick::getLR() {
  int16_t FB, LR;
  boolean b;
  getValue( &FB, &LR, &b );
  return LR;
}

boolean FtSwarmJoystick::getButtonState() {
  int16_t FB, LR;
  boolean b;
  getValue( &FB, &LR, &b );
  return b;
}

void FtSwarmJoystick::getValue( int16_t *FB, int16_t *LR, boolean *buttonState ) {

  if (!me) return;

  static_cast<SwOSJoystick *>(me)->lock();
  static_cast<SwOSJoystick *>(me)->getValue(FB, LR);
  if (button) *buttonState = static_cast<SwOSDigitalInput *>(button)->getValueI32();
  static_cast<SwOSJoystick *>(me)->unlock();
}

void FtSwarmJoystick::onTriggerLR( FtSwarmTrigger_t triggerEvent, FtSwarmOperator_t op, FtSwarmOperand_t v1, FtSwarmOperand_t v2, FtSwarmIO *actor, FtSwarmTriggerParameter p1 ) {

  // set trigger using static values
  if ( (me) && (actor) ) {
    static_cast<SwOSJoystick*>(me)->lock();
    static_cast<SwOSJoystick*>(me)->lr->addEvent( triggerEvent, op, v1, v2, static_cast<SwOSIO *>(actor->me), p1 );
    static_cast<SwOSJoystick*>(me)->unlock();
  }

};

void FtSwarmJoystick::onTriggerFB( FtSwarmTrigger_t triggerEvent, FtSwarmOperator_t op, FtSwarmOperand_t v1, FtSwarmOperand_t v2, FtSwarmIO *actor, FtSwarmTriggerParameter p1 ) {

  // set trigger using static values
  if ( (me) && (actor) ) {
    static_cast<SwOSJoystick*>(me)->lock();
    static_cast<SwOSJoystick*>(me)->fb->addEvent( triggerEvent, op, v1, v2, static_cast<SwOSIO *>(actor->me), p1 );
    static_cast<SwOSJoystick*>(me)->unlock();
  }

};


// **** FtSwarmPixel ****

FtSwarmPixel::FtSwarmPixel( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmIO( serialNumber, port, SWOSIO_PIXEL) {};
FtSwarmPixel::FtSwarmPixel( const char *name ):FtSwarmIO( name, SWOSIO_PIXEL ) {};

uint8_t FtSwarmPixel::getBrightness() {

  if (!me) return 0;
  
  static_cast<SwOSPixel*>(me)->lock();
  uint8_t xReturn = (static_cast<SwOSPixel *>(me)->getBrightness());
  static_cast<SwOSPixel*>(me)->unlock();

  return xReturn;
};

void FtSwarmPixel::setBrightness(uint8_t brightness) {

  if (!me) return;

  static_cast<SwOSPixel*>(me)->lock();
  static_cast<SwOSPixel *>(me)->setBrightness(brightness);
  static_cast<SwOSPixel*>(me)->unlock();
}

CRGB FtSwarmPixel::getColor() {

  if (!me) return CRGB::Black;
  
  static_cast<SwOSPixel*>(me)->lock();
  CRGB xReturn = (static_cast<SwOSPixel *>(me)->getColor());
  static_cast<SwOSPixel*>(me)->unlock();

  return xReturn;
};

void FtSwarmPixel::setColor(CRGB color) {

  if (!me) return;

  static_cast<SwOSPixel*>(me)->lock();
  static_cast<SwOSPixel *>(me)->setColor(color);
  static_cast<SwOSPixel*>(me)->unlock();
}

void FtSwarmPixel::setBlink( uint32_t periodMS, uint8_t signal, uint8_t duty, uint8_t pause, FtSwarmEffectColor_t c1, FtSwarmEffectColor_t c2, FtSwarmEffectColor_t c3 ) {

  if (!me) return;

  SwOSPixel *pixel = static_cast<SwOSPixel*>(me);
  
  FtSwarmTriggerParameter p;
  p.setBlink( periodMS, signal, duty, pause, c1, c2, c3 );

  pixel->lock();
  pixel->setEffect( p );
  pixel->unlock();

}

void FtSwarmPixel::revokeEffect( CRGB color ) {

  if (!me) return;

  SwOSPixel *pixel = static_cast<SwOSPixel*>(me);
  
  FtSwarmTriggerParameter p;
  p.setNone( castColorToUI32( color ) );

  pixel->lock();
  pixel->setEffect( p );
  pixel->unlock();

}

// **** FtSwarmI2C   ****

FtSwarmI2C::FtSwarmI2C( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port ) : FtSwarmIO( serialNumber, port, SWOSIO_I2C ) {
}
    
FtSwarmI2C::FtSwarmI2C( const char *name ) : FtSwarmIO( name, SWOSIO_I2C ) {
}

uint8_t FtSwarmI2C::getRegister(uint8_t reg) {
    
  if (!me) return 0;
  
  static_cast<SwOSI2C*>(me)->lock();
  uint8_t xReturn = (static_cast<SwOSI2C *>(me)->getRegister( reg ));
  static_cast<SwOSI2C*>(me)->unlock();

  return xReturn;
}

void  FtSwarmI2C::setRegister(uint8_t reg, uint8_t value) {

  if (!me) return;

  static_cast<SwOSI2C*>(me)->lock();
  static_cast<SwOSI2C *>(me)->setRegister(reg, value);
  static_cast<SwOSI2C*>(me)->unlock();
}

void FtSwarmI2C::onTrigger( FtSwarmTrigger_t triggerEvent, FtSwarmOperator_t op, FtSwarmOperand_t v1, FtSwarmOperand_t v2, FtSwarmIO *actor, FtSwarmTriggerParameter p1 ) {

  // set trigger using static values
  if ( (me) && (actor) ) {
    static_cast<SwOSI2C*>(me)->lock();
    static_cast<SwOSI2C *>(me)->addEvent( triggerEvent, op, v1, v2, static_cast<SwOSIO*>(actor->me), p1 );
    static_cast<SwOSI2C*>(me)->unlock();
  }

};

// **** FtSwarmGyro   ****

FtSwarmGyro::FtSwarmGyro( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port ) : FtSwarmIO( serialNumber, port, SWOSIO_GYRO ) {
}
    
FtSwarmGyro::FtSwarmGyro( const char *name ) : FtSwarmIO( name, SWOSIO_GYRO ) {
}

void FtSwarmGyro::getYawPitchRoll(float *yaw, float *pitch, float *roll, bool radiants ) {
  
  if (!me) return;
  
  static_cast<SwOSGyro*>(me)->lock();
  static_cast<SwOSGyro*>(me)->getYawPitchRoll( yaw, pitch, roll, radiants );
  static_cast<SwOSGyro*>(me)->unlock();

};

// **** FtSwarmServo ****

FtSwarmServo::FtSwarmServo( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port, SwOSIOType_t ioType ):FtSwarmIO( serialNumber, port, ioType ) {};
FtSwarmServo::FtSwarmServo( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmIO( serialNumber, port, SWOSIO_SERVO) {};
FtSwarmServo::FtSwarmServo( const char *name ):FtSwarmIO( name, SWOSIO_SERVO ) {};

int16_t FtSwarmServo::getPosition() {

  if (!me) return 0;
  
  static_cast<SwOSServo*>(me)->lock();
  int16_t xReturn = (static_cast<SwOSServo *>(me)->getPosition());
  static_cast<SwOSServo*>(me)->unlock();

  return xReturn;
};

void FtSwarmServo::setPosition(int16_t position) {

  if (!me) return;
  
  static_cast<SwOSServo*>(me)->lock();
  static_cast<SwOSServo *>(me)->setPosition( position );
  static_cast<SwOSServo*>(me)->unlock();
}

int16_t FtSwarmServo::getOffset() {

  if (!me) return 0;
  
  static_cast<SwOSServo*>(me)->lock();
  int16_t xReturn = (static_cast<SwOSServo *>(me)->getOffset());
  static_cast<SwOSServo*>(me)->unlock();

  return xReturn;
};

void FtSwarmServo::setOffset(int16_t offset) {

  if (!me) return;
  
  static_cast<SwOSServo*>(me)->lock();
  static_cast<SwOSServo*>(me)->setOffset( offset );
  static_cast<SwOSServo*>(me)->unlock();
}

// **** FtSwarRCServo ****

FtSwarmRCServo::FtSwarmRCServo( FtSwarmSerialNumber_t serialNumber, FtSwarmPort_t port):FtSwarmServo( serialNumber, port, SWOSIO_RCMOTOR) {};
FtSwarmRCServo::FtSwarmRCServo( const char *name ):FtSwarmServo( name ) {};

// **** FtSwarmOLED ****

FtSwarmOLED::FtSwarmOLED(FtSwarmSerialNumber_t serialNumber):FtSwarmIO( serialNumber, SWOSIO_OLED) {};
FtSwarmOLED::FtSwarmOLED( const char *name ):FtSwarmIO( name, SWOSIO_OLED ) {};

void FtSwarmOLED::dim(bool dim) {

  if (!me) return;
  
  static_cast<SwOSOLED*>(me)->lock();
  static_cast<SwOSOLED*>(me)->dim( dim );
  static_cast<SwOSOLED*>(me)->unlock();

}

void FtSwarmOLED::cls( void )  {

  if (!me) return;
  
  static_cast<SwOSOLED*>(me)->lock();
  static_cast<SwOSOLED*>(me)->cls( );
  static_cast<SwOSOLED*>(me)->unlock();

}

void FtSwarmOLED::cls( FtSwarmOledScreen_t screen ) {

  if (!me) return;
  
  static_cast<SwOSOLED*>(me)->lock();
  static_cast<SwOSOLED*>(me)->cls( screen );
  static_cast<SwOSOLED*>(me)->unlock();

}

int16_t FtSwarmOLED::getScreenWidth(void) {

  if (!me) return 0;
  
  static_cast<SwOSOLED*>(me)->lock();
  int16_t xReturn = (static_cast<SwOSOLED *>(me)->getScreenWidth());
  static_cast<SwOSOLED*>(me)->unlock();

  return xReturn;

}

int16_t FtSwarmOLED::getScreenHeight( FtSwarmOledScreen_t screen ) {

  if (!me) return 0;
  
  static_cast<SwOSOLED*>(me)->lock();
  int16_t xReturn = (static_cast<SwOSOLED *>(me)->getScreenHeight());
  static_cast<SwOSOLED*>(me)->unlock();

  return xReturn;

}

int16_t FtSwarmOLED::getTextWidth( const char *text ) {

  if (!me) return 0;
  
  static_cast<SwOSOLED*>(me)->lock();
  int16_t xReturn = (static_cast<SwOSOLED *>(me)->getTextWidth( text ));
  static_cast<SwOSOLED*>(me)->unlock();

  return xReturn;

}


int16_t FtSwarmOLED::getTextHeight( void ) {

  if (!me) return 0;
  
  static_cast<SwOSOLED*>(me)->lock();
  int16_t xReturn = (static_cast<SwOSOLED *>(me)->getTextHeight( ));
  static_cast<SwOSOLED*>(me)->unlock();

  return xReturn;

}

void FtSwarmOLED::drawButton( FtSwarmOledScreen_t screen, int16_t x, int16_t y, uint8_t width, const char *text, uint8_t flags, uint8_t paddingH, uint8_t paddingV ) {

  if (!me) return;
  
  static_cast<SwOSOLED*>(me)->lock();
  static_cast<SwOSOLED*>(me)->drawButton( screen, x, y, width, text, flags, paddingH, paddingV );
  static_cast<SwOSOLED*>(me)->unlock();

}

void FtSwarmOLED::setDrawColor( uint8_t color ) {

  if (!me) return;
  
  static_cast<SwOSOLED*>(me)->lock();
  static_cast<SwOSOLED*>(me)->setDrawColor( color );
  static_cast<SwOSOLED*>(me)->unlock();

}

void FtSwarmOLED::drawCircle( FtSwarmOledScreen_t screen, int16_t x, int16_t y, int16_t r, FtSwarmOledFill_t fill ) {

  if (!me) return;
  
  static_cast<SwOSOLED*>(me)->lock();
  static_cast<SwOSOLED*>(me)->drawCircle( screen, x, y, r, fill );
  static_cast<SwOSOLED*>(me)->unlock();

}

void FtSwarmOLED::drawEllipse( FtSwarmOledScreen_t screen, int16_t x, int16_t y, int16_t rx, int16_t ry, FtSwarmOledFill_t fill ) {

  if (!me) return;
  
  static_cast<SwOSOLED*>(me)->lock();
  static_cast<SwOSOLED*>(me)->drawEllipse( screen, x, y, rx, ry, fill );
  static_cast<SwOSOLED*>(me)->unlock();

}
    
void FtSwarmOLED::drawLine( FtSwarmOledScreen_t screen, int16_t x0, int16_t y0, int16_t x1, int16_t y1 ) {

  if (!me) return;
  
  static_cast<SwOSOLED*>(me)->lock();
  static_cast<SwOSOLED*>(me)->drawLine( screen, x0, y0, x1, y1 );
  static_cast<SwOSOLED*>(me)->unlock();

}
    
void FtSwarmOLED::drawPixel( FtSwarmOledScreen_t screen, int16_t x, int16_t y ) {

  if (!me) return;
  
  static_cast<SwOSOLED*>(me)->lock();
  static_cast<SwOSOLED*>(me)->drawPixel( screen, x, y );
  static_cast<SwOSOLED*>(me)->unlock();

}

void FtSwarmOLED::drawRect( FtSwarmOledScreen_t screen, int16_t x, int16_t y, int16_t w, int16_t h, FtSwarmOledFill_t fill ) {

  if (!me) return;
  
  static_cast<SwOSOLED*>(me)->lock();
  static_cast<SwOSOLED*>(me)->drawRect( screen, x, y, w, h, fill );
  static_cast<SwOSOLED*>(me)->unlock();

}

void FtSwarmOLED::drawRoundRect( FtSwarmOledScreen_t screen, int16_t x, int16_t y, int16_t w, int16_t h, int16_t r, FtSwarmOledFill_t fill ) {

  if (!me) return;
  
  static_cast<SwOSOLED*>(me)->lock();
  static_cast<SwOSOLED*>(me)->drawRoundRect( screen, x, y, w, h, r, fill );
  static_cast<SwOSOLED*>(me)->unlock();

}

void FtSwarmOLED::drawStr( FtSwarmOledScreen_t screen, int16_t x, int16_t y, const char *text, FtSwarmAlign_t align ) {

  if (!me) return;
  
  static_cast<SwOSOLED*>(me)->lock();
  static_cast<SwOSOLED*>(me)->drawStr( screen, x, y, text, align );
  static_cast<SwOSOLED*>(me)->unlock();

}

void FtSwarmOLED::drawStrRect( FtSwarmOledScreen_t screen, int16_t x, int16_t y, int16_t w, const char *text, FtSwarmAlign_t align, uint8_t paddingH, uint8_t paddingV ) {

  if (!me) return;
  
  static_cast<SwOSOLED*>(me)->lock();
  static_cast<SwOSOLED*>(me)->drawStrRect( screen, x, y, w, text, align, paddingH, paddingV );
  static_cast<SwOSOLED*>(me)->unlock();

}

void FtSwarmOLED::drawTriangle( FtSwarmOledScreen_t screen, int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2, int16_t y2, FtSwarmOledFill_t fill ) {

  if (!me) return;
  
  static_cast<SwOSOLED*>(me)->lock();
  static_cast<SwOSOLED*>(me)->drawTriangle( screen, x0, y0, x1, y1, x2, y2 );
  static_cast<SwOSOLED*>(me)->unlock();

}

// **** FtSwarmCAM ****

FtSwarmCAM::FtSwarmCAM( FtSwarmSerialNumber_t serialNumber ):FtSwarmIO( serialNumber, SWOSIO_CAM) {};
FtSwarmCAM::FtSwarmCAM( const char *name ):FtSwarmIO( name, SWOSIO_CAM ) {};

void FtSwarmCAM::streaming( bool onOff ) {

  if (!me) return;

  static_cast<SwOSCAM*>(me)->lock();
  static_cast<SwOSCAM *>(me)->setStreaming( onOff, false);
  static_cast<SwOSCAM*>(me)->unlock();
}

void FtSwarmCAM::setFramesize( framesize_t framesize ) {

  if (!me) return;

  static_cast<SwOSCAM*>(me)->lock();
  static_cast<SwOSCAM *>(me)->setFramesize(framesize, false);
  static_cast<SwOSCAM*>(me)->unlock();
}

void FtSwarmCAM::setQuality( int quality ) {

  if (!me) return;

  static_cast<SwOSCAM*>(me)->lock();
  static_cast<SwOSCAM *>(me)->setQuality( quality, false );
  static_cast<SwOSCAM*>(me)->unlock();
}

void FtSwarmCAM::setBrightness( int brightness ) {

  if (!me) return;

  static_cast<SwOSCAM*>(me)->lock();
  static_cast<SwOSCAM *>(me)->setBrightness(brightness, false);
  static_cast<SwOSCAM*>(me)->unlock();
}

void FtSwarmCAM::setContrast( int contrast ) {

  if (!me) return;

  static_cast<SwOSCAM*>(me)->lock();
  static_cast<SwOSCAM *>(me)->setContrast(contrast, false);
  static_cast<SwOSCAM*>(me)->unlock();
}

void FtSwarmCAM::setSaturation( int saturation ) {

  if (!me) return;

  static_cast<SwOSCAM*>(me)->lock();
  static_cast<SwOSCAM *>(me)->setSaturation(saturation, false);
  static_cast<SwOSCAM*>(me)->unlock();
}

void FtSwarmCAM::setSpecialEffect( int specialEffect ) {

  if (!me) return;

  static_cast<SwOSCAM*>(me)->lock();
  static_cast<SwOSCAM *>(me)->setSpecialEffect(specialEffect, false);
  static_cast<SwOSCAM*>(me)->unlock();
}

void FtSwarmCAM::setWbMode( int wbMode ) {

  if (!me) return;

  static_cast<SwOSCAM*>(me)->lock();
  static_cast<SwOSCAM *>(me)->setWbMode(wbMode, false);
  static_cast<SwOSCAM*>(me)->unlock();
}

void FtSwarmCAM::setHMirror( bool hMirror ) {

  if (!me) return;

  static_cast<SwOSCAM*>(me)->lock();
  static_cast<SwOSCAM *>(me)->setHMirror(hMirror, false);
  static_cast<SwOSCAM*>(me)->unlock();
}

void FtSwarmCAM::setVFlip( bool vFlip ) {

  if (!me) return;

  static_cast<SwOSCAM*>(me)->lock();
  static_cast<SwOSCAM *>(me)->setVFlip(vFlip, false);
  static_cast<SwOSCAM*>(me)->unlock();
}


// **** FtSwarm ****

FtSwarmSerialNumber_t FtSwarm::begin( bool verbose, bool waitOnControllers ) {

  FtSwarmSerialNumber_t result = myOSSwarm.begin( verbose );

  if (!nvs.swarm.IAmKelda) {
    SWARM_LOG_ERROR( TRANSLATE( "Please configure this controller as Kelda.", "Bitte konfigurieren Sie diesen Controller als Kelda." ) );
    firmware();
    ESP.restart();
  }

  while (!myOSSwarm.isOnline()) {
    delay(250);
  }

  return result;

}

void FtSwarm::halt( void ) {

  myOSSwarm.halt( );

}

bool FtSwarm::waitOnUserEvent( int parameter[10], TickType_t xTicksToWait ) {

  SwOSCom userEvent;

  // queue exists?
  if ( !myOSNetwork.userEvent ) return false;
  
  // wait for new event
  if ( xQueueReceive( myOSNetwork.userEvent, &userEvent, xTicksToWait ) == pdTRUE ) {
    for ( uint8_t i=0; i<10; i++ ) {
      memcpy( &parameter[i], &userEvent.data.userEventCmd.payload[ i * sizeof (int ) ], sizeof( int ) );
    }
    return true;
  }

  return false;

}

bool FtSwarm::sendEventData( uint8_t *buffer, size_t size ) {

  // error, if size is to big
  if (size > MAXUSEREVENTPAYLOAD ) return false;

  // ignore, if there is no Kelda
  if (!myOSSwarm.Kelda) return true;

  // create packet
  SwOSCom eventData( myOSSwarm.Kelda->macAddr, myOSSwarm.Ctrl[0]->serialNumber, CMD_USEREVENT );

  // copy payload
  eventData.data.userEventCmd.trigger = false;
  eventData.data.userEventCmd.size = size;
  memcpy( eventData.data.userEventCmd.payload, buffer, size );

  // send
  return true;

}

void forever( char *prompt) {
  printf("%s\n", prompt); while(1) delay(500);
}

void forever( const char *prompt) { forever( (char*) prompt ); }